package com.agrosupply.invoice.dto.request;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
@Data public class PayRequest { @NotBlank private String paymentMethod; }

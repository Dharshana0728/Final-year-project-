package com.agrosupply.invoice.entity;
import com.agrosupply.invoice.enums.InvoiceStatus;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import java.math.BigDecimal;
import java.time.LocalDateTime;
@Entity @Table(name = "invoices") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Invoice {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(name = "farmer_id", nullable = false) private Long farmerId;
    @Column(name = "farmer_name") private String farmerName;
    @Column(name = "request_id", nullable = false) private Long requestId;
    @Column(nullable = false) private BigDecimal totalAmount;
    @CreationTimestamp private LocalDateTime issuedAt;
    private LocalDateTime paidAt;
    private String paymentMethod;
    @Enumerated(EnumType.STRING) @Column(nullable = false) private InvoiceStatus status;
}

package com.agrosupply.invoice.dto.response;
import com.agrosupply.invoice.enums.InvoiceStatus;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
@Data @Builder public class InvoiceResponse { private Long id; private Long farmerId; private String farmerName; private Long requestId; private BigDecimal totalAmount; private InvoiceStatus status; private LocalDateTime issuedAt; private LocalDateTime paidAt; private String paymentMethod; }

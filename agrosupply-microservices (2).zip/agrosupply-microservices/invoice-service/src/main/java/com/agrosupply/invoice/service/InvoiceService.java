package com.agrosupply.invoice.service;
import com.agrosupply.invoice.dto.request.PayRequest;
import com.agrosupply.invoice.dto.response.InvoiceResponse;
import com.agrosupply.invoice.entity.Invoice;
import com.agrosupply.invoice.enums.InvoiceStatus;
import com.agrosupply.invoice.exception.*;
import com.agrosupply.invoice.repository.InvoiceRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;
@Slf4j @Service @RequiredArgsConstructor
public class InvoiceService {
    private final InvoiceRepository invoiceRepository;
    public Invoice createInvoice(Map<String,Object> payload) {
        Invoice inv = invoiceRepository.save(Invoice.builder()
            .requestId(((Number)payload.get("requestId")).longValue())
            .farmerId(((Number)payload.get("farmerId")).longValue())
            .farmerName((String)payload.get("farmerName"))
            .totalAmount(new BigDecimal(payload.get("totalAmount").toString()))
            .status(InvoiceStatus.UNPAID).build());
        log.info("Invoice #{} created — farmer: {}, amount: {}", inv.getId(), inv.getFarmerName(), inv.getTotalAmount());
        return inv;
    }
    public List<InvoiceResponse> getAllInvoices() { return invoiceRepository.findAll().stream().map(this::toResponse).collect(Collectors.toList()); }
    public List<InvoiceResponse> getInvoicesByFarmer(Long farmerId) { return invoiceRepository.findByFarmerId(farmerId).stream().map(this::toResponse).collect(Collectors.toList()); }
    @Transactional
    public InvoiceResponse payInvoice(Long id, PayRequest request) {
        Invoice inv = invoiceRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Invoice not found: " + id));
        if (inv.getStatus() == InvoiceStatus.PAID) throw new BadRequestException("Invoice already paid");
        inv.setStatus(InvoiceStatus.PAID); inv.setPaidAt(LocalDateTime.now()); inv.setPaymentMethod(request.getPaymentMethod());
        return toResponse(invoiceRepository.save(inv));
    }
    private InvoiceResponse toResponse(Invoice i) { return InvoiceResponse.builder().id(i.getId()).farmerId(i.getFarmerId()).farmerName(i.getFarmerName()).requestId(i.getRequestId()).totalAmount(i.getTotalAmount()).status(i.getStatus()).issuedAt(i.getIssuedAt()).paidAt(i.getPaidAt()).paymentMethod(i.getPaymentMethod()).build(); }
}

package com.agrosupply.invoice.repository;
import com.agrosupply.invoice.entity.Invoice;
import com.agrosupply.invoice.enums.InvoiceStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.*;
public interface InvoiceRepository extends JpaRepository<Invoice, Long> {
    List<Invoice> findByFarmerId(Long id);
    List<Invoice> findByStatus(InvoiceStatus status);
    Optional<Invoice> findByRequestId(Long id);
}

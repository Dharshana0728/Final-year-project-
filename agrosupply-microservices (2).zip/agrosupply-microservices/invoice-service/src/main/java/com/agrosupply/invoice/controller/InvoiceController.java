package com.agrosupply.invoice.controller;
import com.agrosupply.invoice.dto.request.PayRequest;
import com.agrosupply.invoice.dto.response.InvoiceResponse;
import com.agrosupply.invoice.entity.Invoice;
import com.agrosupply.invoice.service.InvoiceService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.*;
@RestController @RequestMapping("/api/invoices") @RequiredArgsConstructor
public class InvoiceController {
    private final InvoiceService invoiceService;
    @GetMapping public ResponseEntity<List<InvoiceResponse>> getAll() { return ResponseEntity.ok(invoiceService.getAllInvoices()); }
    @GetMapping("/farmer/{farmerId}") public ResponseEntity<List<InvoiceResponse>> getByFarmer(@PathVariable Long farmerId) { return ResponseEntity.ok(invoiceService.getInvoicesByFarmer(farmerId)); }
    @PatchMapping("/{id}/pay") public ResponseEntity<InvoiceResponse> pay(@PathVariable Long id, @Valid @RequestBody PayRequest r) { return ResponseEntity.ok(invoiceService.payInvoice(id, r)); }
    @PostMapping("/internal/create") public ResponseEntity<Invoice> createInternal(@RequestBody Map<String,Object> payload) { return ResponseEntity.ok(invoiceService.createInvoice(payload)); }
}

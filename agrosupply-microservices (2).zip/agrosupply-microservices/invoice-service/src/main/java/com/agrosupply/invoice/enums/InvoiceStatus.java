package com.agrosupply.invoice.enums;
public enum InvoiceStatus { UNPAID, PAID }

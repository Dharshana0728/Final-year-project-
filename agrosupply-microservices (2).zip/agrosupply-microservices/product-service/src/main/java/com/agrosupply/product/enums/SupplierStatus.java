package com.agrosupply.product.enums;
public enum SupplierStatus { ACTIVE, INACTIVE }

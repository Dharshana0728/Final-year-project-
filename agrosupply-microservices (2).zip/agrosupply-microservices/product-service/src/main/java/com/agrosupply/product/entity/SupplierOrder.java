package com.agrosupply.product.entity;
import com.agrosupply.product.enums.OrderStatus;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import java.time.LocalDateTime;
import java.util.List;
@Entity @Table(name = "supplier_orders") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class SupplierOrder {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @ManyToOne @JoinColumn(name = "supplier_id", nullable = false) private Supplier supplier;
    @Column(name = "procurement_officer_id") private Long procurementOfficerId;
    @Column(name = "procurement_officer_name") private String procurementOfficerName;
    @Enumerated(EnumType.STRING) @Column(nullable = false) private OrderStatus status;
    @CreationTimestamp private LocalDateTime orderedAt;
    private LocalDateTime deliveredAt;
    @OneToMany(mappedBy = "supplierOrder", cascade = CascadeType.ALL) private List<OrderItem> items;
}

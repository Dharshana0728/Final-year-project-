package com.agrosupply.product.client;
import com.agrosupply.product.config.FeignConfig;
import com.agrosupply.product.dto.request.ReceiveStockRequest;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
@FeignClient(name = "WAREHOUSE-SERVICE", configuration = FeignConfig.class)
public interface WarehouseClient {
    @PostMapping("/api/inventory/receive")
    void receiveStock(@RequestBody ReceiveStockRequest request);
}

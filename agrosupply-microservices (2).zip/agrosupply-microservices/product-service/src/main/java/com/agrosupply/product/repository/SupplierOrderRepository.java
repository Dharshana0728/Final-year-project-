package com.agrosupply.product.repository;
import com.agrosupply.product.entity.SupplierOrder;
import com.agrosupply.product.enums.OrderStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface SupplierOrderRepository extends JpaRepository<SupplierOrder, Long> {
    List<SupplierOrder> findByStatus(OrderStatus status);
    List<SupplierOrder> findByProcurementOfficerId(Long id);
}

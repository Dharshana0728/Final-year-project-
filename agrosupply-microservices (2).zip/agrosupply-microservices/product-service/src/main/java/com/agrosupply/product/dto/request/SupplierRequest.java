package com.agrosupply.product.dto.request;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;
@Data public class SupplierRequest { @NotBlank private String name; @NotBlank private String contactInfo; }

package com.agrosupply.product.dto.response;
import lombok.*;
import java.math.BigDecimal;
@Data @Builder public class OrderItemResponse { private Long id; private Long productId; private String productName; private String unit; private Double quantity; private BigDecimal pricePerUnit; private BigDecimal totalPrice; }

package com.agrosupply.product.controller;
import com.agrosupply.product.dto.request.SupplierRequest;
import com.agrosupply.product.dto.response.SupplierResponse;
import com.agrosupply.product.enums.SupplierStatus;
import com.agrosupply.product.service.SupplierService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController @RequestMapping("/api/suppliers") @RequiredArgsConstructor
public class SupplierController {
    private final SupplierService supplierService;
    @PostMapping public ResponseEntity<SupplierResponse> create(@Valid @RequestBody SupplierRequest r) { return ResponseEntity.ok(supplierService.createSupplier(r)); }
    @GetMapping public ResponseEntity<List<SupplierResponse>> getAll() { return ResponseEntity.ok(supplierService.getAllSuppliers()); }
    @PatchMapping("/{id}/status") public ResponseEntity<SupplierResponse> updateStatus(@PathVariable Long id, @RequestParam SupplierStatus status) { return ResponseEntity.ok(supplierService.updateStatus(id, status)); }
}

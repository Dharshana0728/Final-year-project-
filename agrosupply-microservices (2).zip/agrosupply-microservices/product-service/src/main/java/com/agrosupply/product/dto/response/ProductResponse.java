package com.agrosupply.product.dto.response;
import com.agrosupply.product.enums.ProductStatus;
import lombok.*;
import java.math.BigDecimal;
@Data @Builder public class ProductResponse { private Long id; private String name; private String category; private String unit; private BigDecimal price; private ProductStatus status; }

package com.agrosupply.product.dto.request;
import jakarta.validation.constraints.*;
import lombok.Data;
@Data public class OrderItemRequest { @NotNull private Long productId; @NotNull @Positive private Double quantity; }

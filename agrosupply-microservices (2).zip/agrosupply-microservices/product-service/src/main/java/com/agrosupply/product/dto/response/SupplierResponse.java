package com.agrosupply.product.dto.response;
import com.agrosupply.product.enums.SupplierStatus;
import lombok.*;
@Data @Builder public class SupplierResponse { private Long id; private String name; private String contactInfo; private SupplierStatus status; }

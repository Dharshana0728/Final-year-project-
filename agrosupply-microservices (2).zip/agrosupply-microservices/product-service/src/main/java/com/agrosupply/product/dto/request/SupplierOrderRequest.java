package com.agrosupply.product.dto.request;
import jakarta.validation.constraints.*;
import lombok.Data;
import java.util.List;
@Data public class SupplierOrderRequest {
    @NotNull private Long supplierId;
    @NotNull private Long procurementOfficerId;
    @NotNull private String procurementOfficerName;
    @NotEmpty private List<OrderItemRequest> items;
}

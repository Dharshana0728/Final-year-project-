package com.agrosupply.product.controller;
import com.agrosupply.product.dto.request.ProductRequest;
import com.agrosupply.product.dto.response.ProductResponse;
import com.agrosupply.product.enums.ProductStatus;
import com.agrosupply.product.service.ProductService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController @RequestMapping("/api/products") @RequiredArgsConstructor
public class ProductController {
    private final ProductService productService;
    @PostMapping public ResponseEntity<ProductResponse> create(@Valid @RequestBody ProductRequest r) { return ResponseEntity.ok(productService.createProduct(r)); }
    @GetMapping public ResponseEntity<List<ProductResponse>> getAll() { return ResponseEntity.ok(productService.getAllProducts()); }
    @GetMapping("/{id}") public ResponseEntity<ProductResponse> getById(@PathVariable Long id) { return ResponseEntity.ok(productService.getProductById(id)); }
    @PutMapping("/{id}") public ResponseEntity<ProductResponse> update(@PathVariable Long id, @Valid @RequestBody ProductRequest r) { return ResponseEntity.ok(productService.updateProduct(id, r)); }
    @PatchMapping("/{id}/status") public ResponseEntity<ProductResponse> updateStatus(@PathVariable Long id, @RequestParam ProductStatus status) { return ResponseEntity.ok(productService.updateStatus(id, status)); }
}

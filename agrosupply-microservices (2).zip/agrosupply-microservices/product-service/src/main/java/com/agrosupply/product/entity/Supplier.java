package com.agrosupply.product.entity;
import com.agrosupply.product.enums.SupplierStatus;
import jakarta.persistence.*;
import lombok.*;
@Entity @Table(name = "suppliers") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Supplier {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(nullable = false) private String name;
    private String contactInfo;
    @Enumerated(EnumType.STRING) @Column(nullable = false) private SupplierStatus status;
}

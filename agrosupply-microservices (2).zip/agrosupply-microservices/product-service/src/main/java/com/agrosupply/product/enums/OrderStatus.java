package com.agrosupply.product.enums;
public enum OrderStatus { PENDING, DELIVERED, CANCELLED }

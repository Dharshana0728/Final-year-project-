package com.agrosupply.product.service;
import com.agrosupply.product.client.WarehouseClient;
import com.agrosupply.product.dto.request.*;
import com.agrosupply.product.dto.response.*;
import com.agrosupply.product.entity.*;
import com.agrosupply.product.enums.OrderStatus;
import com.agrosupply.product.exception.*;
import com.agrosupply.product.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;
@Slf4j @Service @RequiredArgsConstructor
public class SupplierOrderService {
    private final SupplierOrderRepository supplierOrderRepository;
    private final SupplierRepository supplierRepository;
    private final ProductRepository productRepository;
    private final WarehouseClient warehouseClient;

    @Transactional
    public SupplierOrderResponse createOrder(SupplierOrderRequest request) {
        Supplier supplier = supplierRepository.findById(request.getSupplierId()).orElseThrow(() -> new ResourceNotFoundException("Supplier not found: " + request.getSupplierId()));
        SupplierOrder order = SupplierOrder.builder().supplier(supplier).procurementOfficerId(request.getProcurementOfficerId()).procurementOfficerName(request.getProcurementOfficerName()).status(OrderStatus.PENDING).build();
        order = supplierOrderRepository.save(order);
        List<OrderItem> items = new ArrayList<>();
        for (OrderItemRequest ir : request.getItems()) {
            Product p = productRepository.findById(ir.getProductId()).orElseThrow(() -> new ResourceNotFoundException("Product not found: " + ir.getProductId()));
            items.add(OrderItem.builder().supplierOrder(order).product(p).quantity(ir.getQuantity()).build());
        }
        order.setItems(items);
        return toResponse(supplierOrderRepository.save(order));
    }

    public List<SupplierOrderResponse> getAllOrders() { return supplierOrderRepository.findAll().stream().map(this::toResponse).collect(Collectors.toList()); }

    @Transactional
    public SupplierOrderResponse markDelivered(Long orderId, Long warehouseId) {
        SupplierOrder order = supplierOrderRepository.findById(orderId).orElseThrow(() -> new ResourceNotFoundException("Order not found: " + orderId));
        if (order.getStatus() != OrderStatus.PENDING) throw new BadRequestException("Only PENDING orders can be marked delivered");
        ReceiveStockRequest stockRequest = new ReceiveStockRequest();
        stockRequest.setWarehouseId(warehouseId);
        List<ReceiveStockRequest.StockItem> stockItems = order.getItems().stream().map(i -> { var si = new ReceiveStockRequest.StockItem(); si.setProductId(i.getProduct().getId()); si.setProductName(i.getProduct().getName()); si.setProductUnit(i.getProduct().getUnit()); si.setQuantity(i.getQuantity()); return si; }).collect(Collectors.toList());
        stockRequest.setItems(stockItems);
        warehouseClient.receiveStock(stockRequest);
        order.setStatus(OrderStatus.DELIVERED); order.setDeliveredAt(LocalDateTime.now());
        return toResponse(supplierOrderRepository.save(order));
    }

    @Transactional
    public SupplierOrderResponse cancelOrder(Long orderId) {
        SupplierOrder order = supplierOrderRepository.findById(orderId).orElseThrow(() -> new ResourceNotFoundException("Order not found: " + orderId));
        if (order.getStatus() != OrderStatus.PENDING) throw new BadRequestException("Only PENDING orders can be cancelled");
        order.setStatus(OrderStatus.CANCELLED);
        return toResponse(supplierOrderRepository.save(order));
    }

    private SupplierOrderResponse toResponse(SupplierOrder o) {
        List<OrderItemResponse> items = o.getItems().stream().map(i -> OrderItemResponse.builder().id(i.getId()).productId(i.getProduct().getId()).productName(i.getProduct().getName()).unit(i.getProduct().getUnit()).quantity(i.getQuantity()).pricePerUnit(i.getProduct().getPrice()).totalPrice(i.getProduct().getPrice().multiply(BigDecimal.valueOf(i.getQuantity()))).build()).collect(Collectors.toList());
        return SupplierOrderResponse.builder().id(o.getId()).supplierId(o.getSupplier().getId()).supplierName(o.getSupplier().getName()).procurementOfficerId(o.getProcurementOfficerId()).procurementOfficerName(o.getProcurementOfficerName()).items(items).status(o.getStatus()).orderedAt(o.getOrderedAt()).deliveredAt(o.getDeliveredAt()).build();
    }
}

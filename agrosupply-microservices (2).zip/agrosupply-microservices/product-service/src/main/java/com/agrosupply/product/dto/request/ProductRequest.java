package com.agrosupply.product.dto.request;
import jakarta.validation.constraints.*;
import lombok.Data;
import java.math.BigDecimal;
@Data public class ProductRequest {
    @NotBlank private String name; @NotBlank private String category; @NotBlank private String unit;
    @NotNull @Positive private BigDecimal price;
}

package com.agrosupply.product.repository;
import com.agrosupply.product.entity.Product;
import com.agrosupply.product.enums.ProductStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface ProductRepository extends JpaRepository<Product, Long> {
    List<Product> findByStatus(ProductStatus status);
    List<Product> findByCategory(String category);
}

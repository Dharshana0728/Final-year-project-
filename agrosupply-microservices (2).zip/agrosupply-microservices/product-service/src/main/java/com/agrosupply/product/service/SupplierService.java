package com.agrosupply.product.service;
import com.agrosupply.product.dto.request.SupplierRequest;
import com.agrosupply.product.dto.response.SupplierResponse;
import com.agrosupply.product.entity.Supplier;
import com.agrosupply.product.enums.SupplierStatus;
import com.agrosupply.product.exception.ResourceNotFoundException;
import com.agrosupply.product.repository.SupplierRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;
@Slf4j @Service @RequiredArgsConstructor
public class SupplierService {
    private final SupplierRepository supplierRepository;
    public SupplierResponse createSupplier(SupplierRequest request) {
        Supplier s = supplierRepository.save(Supplier.builder().name(request.getName()).contactInfo(request.getContactInfo()).status(SupplierStatus.ACTIVE).build());
        return toResponse(s);
    }
    public List<SupplierResponse> getAllSuppliers() { return supplierRepository.findAll().stream().map(this::toResponse).collect(Collectors.toList()); }
    public SupplierResponse updateStatus(Long id, SupplierStatus status) {
        Supplier s = supplierRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Supplier not found: " + id));
        s.setStatus(status); supplierRepository.save(s); return toResponse(s);
    }
    private SupplierResponse toResponse(Supplier s) { return SupplierResponse.builder().id(s.getId()).name(s.getName()).contactInfo(s.getContactInfo()).status(s.getStatus()).build(); }
}

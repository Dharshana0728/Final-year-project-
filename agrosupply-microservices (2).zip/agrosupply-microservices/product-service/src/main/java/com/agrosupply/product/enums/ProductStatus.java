package com.agrosupply.product.enums;
public enum ProductStatus { ACTIVE, INACTIVE }

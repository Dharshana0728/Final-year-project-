package com.agrosupply.product.entity;
import com.agrosupply.product.enums.ProductStatus;
import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
@Entity @Table(name = "products") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Product {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(nullable = false) private String name;
    @Column(nullable = false) private String category;
    @Column(nullable = false) private String unit;
    @Column(nullable = false) private BigDecimal price;
    @Enumerated(EnumType.STRING) @Column(nullable = false) private ProductStatus status;
}

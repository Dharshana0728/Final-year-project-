package com.agrosupply.product.dto.response;
import com.agrosupply.product.enums.OrderStatus;
import lombok.*;
import java.time.LocalDateTime;
import java.util.List;
@Data @Builder public class SupplierOrderResponse {
    private Long id; private Long supplierId; private String supplierName;
    private Long procurementOfficerId; private String procurementOfficerName;
    private List<OrderItemResponse> items; private OrderStatus status;
    private LocalDateTime orderedAt; private LocalDateTime deliveredAt;
}

package com.agrosupply.product.exception;
public class CapacityExceededException extends RuntimeException { public CapacityExceededException(String m) { super(m); } }

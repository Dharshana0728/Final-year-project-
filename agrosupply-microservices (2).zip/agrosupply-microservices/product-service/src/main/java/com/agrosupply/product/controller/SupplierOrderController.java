package com.agrosupply.product.controller;
import com.agrosupply.product.dto.request.SupplierOrderRequest;
import com.agrosupply.product.dto.response.SupplierOrderResponse;
import com.agrosupply.product.service.SupplierOrderService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController @RequestMapping("/api/supplier-orders") @RequiredArgsConstructor
public class SupplierOrderController {
    private final SupplierOrderService supplierOrderService;
    @PostMapping public ResponseEntity<SupplierOrderResponse> create(@Valid @RequestBody SupplierOrderRequest r) { return ResponseEntity.ok(supplierOrderService.createOrder(r)); }
    @GetMapping public ResponseEntity<List<SupplierOrderResponse>> getAll() { return ResponseEntity.ok(supplierOrderService.getAllOrders()); }
    @PatchMapping("/{id}/deliver") public ResponseEntity<SupplierOrderResponse> deliver(@PathVariable Long id, @RequestParam Long warehouseId) { return ResponseEntity.ok(supplierOrderService.markDelivered(id, warehouseId)); }
    @PatchMapping("/{id}/cancel") public ResponseEntity<SupplierOrderResponse> cancel(@PathVariable Long id) { return ResponseEntity.ok(supplierOrderService.cancelOrder(id)); }
}

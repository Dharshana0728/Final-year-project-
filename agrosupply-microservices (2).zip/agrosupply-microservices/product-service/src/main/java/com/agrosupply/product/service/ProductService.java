package com.agrosupply.product.service;
import com.agrosupply.product.dto.request.ProductRequest;
import com.agrosupply.product.dto.response.ProductResponse;
import com.agrosupply.product.entity.Product;
import com.agrosupply.product.enums.ProductStatus;
import com.agrosupply.product.exception.ResourceNotFoundException;
import com.agrosupply.product.repository.ProductRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;
@Slf4j @Service @RequiredArgsConstructor
public class ProductService {
    private final ProductRepository productRepository;
    public ProductResponse createProduct(ProductRequest request) {
        Product p = productRepository.save(Product.builder().name(request.getName()).category(request.getCategory()).unit(request.getUnit()).price(request.getPrice()).status(ProductStatus.ACTIVE).build());
        return toResponse(p);
    }
    public List<ProductResponse> getAllProducts() { return productRepository.findAll().stream().map(this::toResponse).collect(Collectors.toList()); }
    public ProductResponse getProductById(Long id) { return toResponse(productRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Product not found: " + id))); }
    public ProductResponse updateProduct(Long id, ProductRequest request) {
        Product p = productRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Product not found: " + id));
        p.setName(request.getName()); p.setCategory(request.getCategory()); p.setUnit(request.getUnit()); p.setPrice(request.getPrice());
        return toResponse(productRepository.save(p));
    }
    public ProductResponse updateStatus(Long id, ProductStatus status) {
        Product p = productRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Product not found: " + id));
        p.setStatus(status); return toResponse(productRepository.save(p));
    }
    public ProductResponse toResponse(Product p) { return ProductResponse.builder().id(p.getId()).name(p.getName()).category(p.getCategory()).unit(p.getUnit()).price(p.getPrice()).status(p.getStatus()).build(); }
}

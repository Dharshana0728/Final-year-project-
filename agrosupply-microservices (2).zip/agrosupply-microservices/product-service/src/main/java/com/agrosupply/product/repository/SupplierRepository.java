package com.agrosupply.product.repository;
import com.agrosupply.product.entity.Supplier;
import com.agrosupply.product.enums.SupplierStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface SupplierRepository extends JpaRepository<Supplier, Long> {
    List<Supplier> findByStatus(SupplierStatus status);
}

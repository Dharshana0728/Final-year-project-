package com.agrosupply.request.service;

import com.agrosupply.request.client.*;
import com.agrosupply.request.dto.request.*;
import com.agrosupply.request.dto.response.*;
import com.agrosupply.request.entity.*;
import com.agrosupply.request.enums.*;
import com.agrosupply.request.exception.*;
import com.agrosupply.request.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j @Service @RequiredArgsConstructor
public class FarmerRequestService {
    private final FarmerRequestRepository farmerRequestRepository;
    private final RequestItemRepository requestItemRepository;
    private final AuthClient authClient;
    private final ProductClient productClient;
    private final WarehouseClient warehouseClient;
    private final DeliveryClient deliveryClient;

    @Transactional
    public FarmerRequestResponse createRequest(FarmerRequestRequest request) {
        log.info("Creating farmer request for farmerId: {}", request.getFarmerId());

        // Step 1: Validate farmer
        Map<String,Object> farmer = authClient.getUserById(request.getFarmerId());
        if (!"FARMER".equals(farmer.get("role"))) throw new BadRequestException("User is not a farmer");
        if (!"ACTIVE".equals(farmer.get("status"))) throw new BadRequestException("Farmer account is not active");

        // Step 2: Validate products and build items
        List<CheckAndDeductRequest.Item> stockItems = new ArrayList<>();
        List<Map<String,Object>> products = new ArrayList<>();
        for (RequestItemRequest ir : request.getItems()) {
            Map<String,Object> product = productClient.getProductById(ir.getProductId());
            if (!"ACTIVE".equals(product.get("status"))) throw new BadRequestException("Product not available: " + product.get("name"));
            products.add(product);
            var si = new CheckAndDeductRequest.Item();
            si.setProductId(ir.getProductId()); si.setProductUnit((String) product.get("unit")); si.setQuantity(ir.getQuantity());
            stockItems.add(si);
        }

        // Step 3: Check and deduct warehouse stock
        CheckAndDeductRequest cdr = new CheckAndDeductRequest(); cdr.setItems(stockItems);
        Map<String,Object> warehouseResult = warehouseClient.checkAndDeduct(cdr);
        Long warehouseId = ((Number) warehouseResult.get("warehouseId")).longValue();
        String warehouseName = (String) warehouseResult.get("warehouseName");

        // Step 4: Find least busy agent
        List<Map<String,Object>> agents = authClient.getActiveDeliveryAgents();
        if (agents.isEmpty()) throw new BadRequestException("No delivery agents available");
        Map<String,Object> selectedAgent = agents.stream()
            .min(Comparator.comparingLong(a -> farmerRequestRepository.countActiveDeliveriesByAgent(((Number)a.get("id")).longValue())))
            .orElseThrow(() -> new BadRequestException("Could not assign agent"));

        Long agentId = ((Number) selectedAgent.get("id")).longValue();
        String agentName = (String) selectedAgent.get("name");

        // Step 5: Save request
        FarmerRequest farmerRequest = farmerRequestRepository.save(FarmerRequest.builder()
            .farmerId(request.getFarmerId()).farmerName((String)farmer.get("name"))
            .warehouseId(warehouseId).warehouseName(warehouseName)
            .deliveryAgentId(agentId).deliveryAgentName(agentName)
            .status(RequestStatus.SCHEDULED).scheduledAt(LocalDateTime.now()).build());

        // Step 6: Save items
        List<RequestItem> items = new ArrayList<>();
        for (int i = 0; i < request.getItems().size(); i++) {
            var ir = request.getItems().get(i);
            var product = products.get(i);
            BigDecimal price = new BigDecimal(product.get("price").toString());
            items.add(requestItemRepository.save(RequestItem.builder()
                .farmerRequest(farmerRequest)
                .productId(ir.getProductId()).productName((String)product.get("name"))
                .productUnit((String)product.get("unit")).productPrice(price)
                .quantity(ir.getQuantity()).status(RequestItemStatus.ALLOCATED).build()));
        }
        farmerRequest.setItems(items);

        // Step 7: Auto-create delivery
        Map<String,Object> deliveryPayload = new HashMap<>();
        deliveryPayload.put("requestId", farmerRequest.getId());
        deliveryPayload.put("farmerId", farmerRequest.getFarmerId()); deliveryPayload.put("farmerName", farmerRequest.getFarmerName());
        deliveryPayload.put("warehouseId", warehouseId); deliveryPayload.put("warehouseName", warehouseName);
        deliveryPayload.put("deliveryAgentId", agentId); deliveryPayload.put("deliveryAgentName", agentName);
        deliveryClient.createDelivery(deliveryPayload);

        log.info("Farmer request #{} created successfully", farmerRequest.getId());
        return toResponse(farmerRequest);
    }

    public List<FarmerRequestResponse> getAllRequests() { return farmerRequestRepository.findAll().stream().map(this::toResponse).collect(Collectors.toList()); }
    public FarmerRequestResponse getRequestById(Long id) { return toResponse(farmerRequestRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Request not found: " + id))); }
    public List<FarmerRequestResponse> getRequestsByFarmer(Long farmerId) { return farmerRequestRepository.findByFarmerId(farmerId).stream().map(this::toResponse).collect(Collectors.toList()); }

    @Transactional
    public FarmerRequestResponse cancelRequest(Long id) {
        FarmerRequest req = farmerRequestRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Request not found: " + id));
        if (req.getStatus() == RequestStatus.DELIVERED) throw new BadRequestException("Cannot cancel a delivered request");
        if (req.getStatus() == RequestStatus.CANCELLED) throw new BadRequestException("Request already cancelled");

        // Restore stock
        RestoreStockRequest rsr = new RestoreStockRequest();
        rsr.setItems(req.getItems().stream().map(item -> { var i = new RestoreStockRequest.Item(); i.setProductId(item.getProductId()); i.setQuantity(item.getQuantity()); return i; }).collect(Collectors.toList()));
        warehouseClient.restoreStock(req.getWarehouseId(), rsr);
        req.setStatus(RequestStatus.CANCELLED);
        return toResponse(farmerRequestRepository.save(req));
    }

    public FarmerRequestResponse markDelivered(Long id) {
        FarmerRequest req = farmerRequestRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Request not found: " + id));
        req.setStatus(RequestStatus.DELIVERED);
        return toResponse(farmerRequestRepository.save(req));
    }

    public FarmerRequestResponse getRequestForInvoice(Long id) { return getRequestById(id); }

    private FarmerRequestResponse toResponse(FarmerRequest r) {
        List<RequestItemResponse> items = r.getItems() == null ? List.of() : r.getItems().stream().map(i -> RequestItemResponse.builder()
            .id(i.getId()).productId(i.getProductId()).productName(i.getProductName())
            .productUnit(i.getProductUnit()).productPrice(i.getProductPrice()).quantity(i.getQuantity())
            .totalPrice(i.getProductPrice() != null ? i.getProductPrice().multiply(BigDecimal.valueOf(i.getQuantity())) : null)
            .status(i.getStatus()).build()).collect(Collectors.toList());
        return FarmerRequestResponse.builder().id(r.getId()).farmerId(r.getFarmerId()).farmerName(r.getFarmerName())
            .warehouseId(r.getWarehouseId()).warehouseName(r.getWarehouseName())
            .deliveryAgentId(r.getDeliveryAgentId()).deliveryAgentName(r.getDeliveryAgentName())
            .items(items).status(r.getStatus()).requestedAt(r.getRequestedAt()).scheduledAt(r.getScheduledAt()).build();
    }
}

package com.agrosupply.request.dto.response;
import com.agrosupply.request.enums.RequestStatus;
import lombok.*;
import java.time.LocalDateTime;
import java.util.List;
@Data @Builder public class FarmerRequestResponse { private Long id; private Long farmerId; private String farmerName; private Long warehouseId; private String warehouseName; private Long deliveryAgentId; private String deliveryAgentName; private List<RequestItemResponse> items; private RequestStatus status; private LocalDateTime requestedAt; private LocalDateTime scheduledAt; }

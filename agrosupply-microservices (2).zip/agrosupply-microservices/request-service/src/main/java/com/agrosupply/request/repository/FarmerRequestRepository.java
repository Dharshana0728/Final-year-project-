package com.agrosupply.request.repository;
import com.agrosupply.request.entity.FarmerRequest;
import com.agrosupply.request.enums.RequestStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;
public interface FarmerRequestRepository extends JpaRepository<FarmerRequest, Long> {
    List<FarmerRequest> findByFarmerId(Long id);
    List<FarmerRequest> findByStatus(RequestStatus status);
    List<FarmerRequest> findByDeliveryAgentId(Long id);
    @Query("SELECT COUNT(r) FROM FarmerRequest r WHERE r.deliveryAgentId = :agentId AND r.status IN (com.agrosupply.request.enums.RequestStatus.SCHEDULED, com.agrosupply.request.enums.RequestStatus.DELIVERED)")
    Long countActiveDeliveriesByAgent(@Param("agentId") Long agentId);
}

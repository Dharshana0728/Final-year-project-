package com.agrosupply.request.enums;
public enum RequestStatus { PENDING, ALLOCATED, SCHEDULED, DELIVERED, CANCELLED }

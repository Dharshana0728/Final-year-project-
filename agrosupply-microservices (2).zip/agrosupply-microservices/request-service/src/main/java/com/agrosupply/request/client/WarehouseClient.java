package com.agrosupply.request.client;
import com.agrosupply.request.config.FeignConfig;
import com.agrosupply.request.dto.request.CheckAndDeductRequest;
import com.agrosupply.request.dto.request.RestoreStockRequest;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@FeignClient(name = "WAREHOUSE-SERVICE", configuration = FeignConfig.class)
public interface WarehouseClient {
    @PostMapping("/api/inventory/check-and-deduct") Map<String,Object> checkAndDeduct(@RequestBody CheckAndDeductRequest r);
    @PostMapping("/api/inventory/restore/{warehouseId}") void restoreStock(@PathVariable Long warehouseId, @RequestBody RestoreStockRequest r);
}
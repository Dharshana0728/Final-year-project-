package com.agrosupply.request.entity;
import com.agrosupply.request.enums.RequestStatus;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import java.time.LocalDateTime;
import java.util.List;
@Entity @Table(name = "farmer_requests") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class FarmerRequest {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(name = "farmer_id", nullable = false) private Long farmerId;
    @Column(name = "farmer_name") private String farmerName;
    @Column(name = "warehouse_id") private Long warehouseId;
    @Column(name = "warehouse_name") private String warehouseName;
    @Column(name = "delivery_agent_id") private Long deliveryAgentId;
    @Column(name = "delivery_agent_name") private String deliveryAgentName;
    @Enumerated(EnumType.STRING) @Column(nullable = false) private RequestStatus status;
    @CreationTimestamp private LocalDateTime requestedAt;
    private LocalDateTime scheduledAt;
    @OneToMany(mappedBy = "farmerRequest", cascade = CascadeType.ALL) private List<RequestItem> items;
}

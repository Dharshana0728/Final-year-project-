package com.agrosupply.request.client;
import com.agrosupply.request.config.FeignConfig;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@FeignClient(name = "PRODUCT-SERVICE", configuration = FeignConfig.class)
public interface ProductClient {
    @GetMapping("/api/products/{id}") Map<String,Object> getProductById(@PathVariable Long id);
}
package com.agrosupply.request.client;
import com.agrosupply.request.config.FeignConfig;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@FeignClient(name = "DELIVERY-SERVICE", configuration = FeignConfig.class)
public interface DeliveryClient {
    @PostMapping("/api/deliveries/internal/create") void createDelivery(@RequestBody Map<String,Object> payload);
}
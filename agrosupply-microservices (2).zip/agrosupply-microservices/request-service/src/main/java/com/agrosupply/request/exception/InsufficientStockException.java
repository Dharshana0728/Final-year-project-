package com.agrosupply.request.exception;
public class InsufficientStockException extends RuntimeException { public InsufficientStockException(String m) { super(m); } }

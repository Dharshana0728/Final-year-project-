package com.agrosupply.request.repository;
import com.agrosupply.request.entity.RequestItem;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface RequestItemRepository extends JpaRepository<RequestItem, Long> {
    List<RequestItem> findByFarmerRequestId(Long id);
}

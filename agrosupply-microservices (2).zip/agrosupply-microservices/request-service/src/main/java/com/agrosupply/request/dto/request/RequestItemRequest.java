package com.agrosupply.request.dto.request;
import jakarta.validation.constraints.*;
import lombok.Data;
@Data public class RequestItemRequest { @NotNull private Long productId; @NotNull @Positive private Double quantity; }

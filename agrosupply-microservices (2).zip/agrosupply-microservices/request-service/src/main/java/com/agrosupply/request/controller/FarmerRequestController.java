package com.agrosupply.request.controller;
import com.agrosupply.request.dto.request.FarmerRequestRequest;
import com.agrosupply.request.dto.response.FarmerRequestResponse;
import com.agrosupply.request.service.FarmerRequestService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController @RequestMapping("/api/requests") @RequiredArgsConstructor
public class FarmerRequestController {
    private final FarmerRequestService farmerRequestService;

    @PostMapping public ResponseEntity<FarmerRequestResponse> createRequest(@RequestBody FarmerRequestRequest request) { return ResponseEntity.ok(farmerRequestService.createRequest(request)); }
    @GetMapping public ResponseEntity<List<FarmerRequestResponse>> getAllRequests() { return ResponseEntity.ok(farmerRequestService.getAllRequests()); }
    @GetMapping("/{id}") public ResponseEntity<FarmerRequestResponse> getRequestById(@PathVariable Long id) { return ResponseEntity.ok(farmerRequestService.getRequestById(id)); }
    @GetMapping("/farmer/{farmerId}") public ResponseEntity<List<FarmerRequestResponse>> getRequestsByFarmer(@PathVariable Long farmerId) { return ResponseEntity.ok(farmerRequestService.getRequestsByFarmer(farmerId)); }
    @PostMapping("/{id}/cancel") public ResponseEntity<FarmerRequestResponse> cancelRequest(@PathVariable Long id) { return ResponseEntity.ok(farmerRequestService.cancelRequest(id)); }

    // Internal endpoints — POST instead of PATCH (Feign default client doesn't support PATCH)
    @PostMapping("/internal/{id}/delivered") public ResponseEntity<FarmerRequestResponse> markDelivered(@PathVariable Long id) { return ResponseEntity.ok(farmerRequestService.markDelivered(id)); }
    @GetMapping("/internal/{id}") public ResponseEntity<FarmerRequestResponse> getRequestForDelivery(@PathVariable Long id) { return ResponseEntity.ok(farmerRequestService.getRequestForInvoice(id)); }
}
package com.agrosupply.request.dto.response;
import com.agrosupply.request.enums.RequestItemStatus;
import lombok.*;
import java.math.BigDecimal;
@Data @Builder public class RequestItemResponse { private Long id; private Long productId; private String productName; private String productUnit; private BigDecimal productPrice; private Double quantity; private BigDecimal totalPrice; private RequestItemStatus status; }

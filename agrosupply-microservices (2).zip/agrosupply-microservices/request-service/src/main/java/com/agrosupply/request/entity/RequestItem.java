package com.agrosupply.request.entity;
import com.agrosupply.request.enums.RequestItemStatus;
import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
@Entity @Table(name = "request_items") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class RequestItem {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @ManyToOne @JoinColumn(name = "farmer_request_id", nullable = false) private FarmerRequest farmerRequest;
    @Column(name = "product_id", nullable = false) private Long productId;
    @Column(name = "product_name") private String productName;
    @Column(name = "product_unit") private String productUnit;
    @Column(name = "product_price") private BigDecimal productPrice;
    @Column(nullable = false) private Double quantity;
    @Enumerated(EnumType.STRING) @Column(nullable = false) private RequestItemStatus status;
}

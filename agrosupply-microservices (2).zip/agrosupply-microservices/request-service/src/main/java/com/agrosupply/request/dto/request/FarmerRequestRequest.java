package com.agrosupply.request.dto.request;
import jakarta.validation.constraints.*;
import lombok.Data;
import java.util.List;
@Data public class FarmerRequestRequest { @NotNull private Long farmerId; @NotEmpty private List<RequestItemRequest> items; }

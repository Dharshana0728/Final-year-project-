package com.agrosupply.request.enums;
public enum RequestItemStatus { PENDING, ALLOCATED }

package com.agrosupply.request.client;
import com.agrosupply.request.config.FeignConfig;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;

@FeignClient(name = "AUTH-SERVICE", configuration = FeignConfig.class)
public interface AuthClient {
    @GetMapping("/api/users/{id}") Map<String,Object> getUserById(@PathVariable Long id);
    @GetMapping("/api/users/delivery-agents") List<Map<String,Object>> getActiveDeliveryAgents();
}
package com.agrosupply.auth.config;
import com.agrosupply.auth.entity.User;
import com.agrosupply.auth.enums.Role;
import com.agrosupply.auth.enums.UserStatus;
import com.agrosupply.auth.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
@Component @RequiredArgsConstructor
public class DataInitializer implements CommandLineRunner {
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    @Override
    public void run(String... args) {
        if (!userRepository.existsByEmail("admin@agrosupply.com")) {
            userRepository.save(User.builder().name("Admin").email("admin@agrosupply.com")
                .password(passwordEncoder.encode("admin123")).phone("0000000000")
                .role(Role.ADMIN).status(UserStatus.ACTIVE).build());
            System.out.println("Admin created — email: admin@agrosupply.com | password: admin123");
        }
    }
}

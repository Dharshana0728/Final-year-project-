package com.agrosupply.auth.dto.request;
import com.agrosupply.auth.enums.Role;
import jakarta.validation.constraints.*;
import lombok.Data;
@Data
public class RegisterRequest {
    @NotBlank private String name;
    @Email @NotBlank private String email;
    @NotBlank private String password;
    private String phone;
    private String location;
    @NotNull private Role role;
}

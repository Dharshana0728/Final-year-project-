package com.agrosupply.auth.controller;
import com.agrosupply.auth.dto.response.UserResponse;
import com.agrosupply.auth.enums.UserStatus;
import com.agrosupply.auth.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController @RequestMapping("/api/users") @RequiredArgsConstructor
public class UserController {
    private final UserService userService;
    @GetMapping public ResponseEntity<List<UserResponse>> getAllUsers() { return ResponseEntity.ok(userService.getAllUsers()); }
    @GetMapping("/{id}") public ResponseEntity<UserResponse> getUserById(@PathVariable Long id) { return ResponseEntity.ok(userService.getUserById(id)); }
    @GetMapping("/delivery-agents") public ResponseEntity<List<UserResponse>> getActiveDeliveryAgents() { return ResponseEntity.ok(userService.getActiveDeliveryAgents()); }
    @PatchMapping("/{id}/status") public ResponseEntity<UserResponse> updateStatus(@PathVariable Long id, @RequestParam UserStatus status) { return ResponseEntity.ok(userService.updateUserStatus(id, status)); }
}

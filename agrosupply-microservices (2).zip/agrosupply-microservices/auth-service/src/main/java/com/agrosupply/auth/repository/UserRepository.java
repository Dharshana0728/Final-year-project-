package com.agrosupply.auth.repository;
import com.agrosupply.auth.entity.User;
import com.agrosupply.auth.enums.Role;
import com.agrosupply.auth.enums.UserStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.*;
public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByEmail(String email);
    List<User> findByStatus(UserStatus status);
    List<User> findByRole(Role role);
    boolean existsByEmail(String email);
    List<User> findByRoleAndStatus(Role role, UserStatus status);
}

package com.agrosupply.auth.service;
import com.agrosupply.auth.dto.request.*;
import com.agrosupply.auth.dto.response.AuthResponse;
import com.agrosupply.auth.entity.User;
import com.agrosupply.auth.enums.*;
import com.agrosupply.auth.exception.*;
import com.agrosupply.auth.repository.UserRepository;
import com.agrosupply.auth.security.JwtUtil;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
@Slf4j @Service @RequiredArgsConstructor
public class AuthService {
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;
    public AuthResponse register(RegisterRequest request) {
        log.info("Registration attempt for: {}", request.getEmail());
        if (userRepository.existsByEmail(request.getEmail())) throw new BadRequestException("Email already registered");
        UserStatus status = (request.getRole() == Role.FARMER) ? UserStatus.ACTIVE : UserStatus.PENDING;
        User user = userRepository.save(User.builder().name(request.getName()).email(request.getEmail())
            .password(passwordEncoder.encode(request.getPassword())).phone(request.getPhone())
            .location(request.getLocation()).role(request.getRole()).status(status).build());
        String token = (status == UserStatus.ACTIVE) ? jwtUtil.generateToken(user.getEmail(), user.getRole().name()) : null;
        String message = (status == UserStatus.ACTIVE) ? "Registration successful" : "Registration successful. Awaiting admin approval.";
        return AuthResponse.builder().id(user.getId()).token(token).name(user.getName()).email(user.getEmail()).role(user.getRole()).status(user.getStatus()).message(message).build();
    }
    public AuthResponse login(LoginRequest request) {
        log.info("Login attempt for: {}", request.getEmail());
        User user = userRepository.findByEmail(request.getEmail()).orElseThrow(() -> new UnauthorizedException("Invalid email or password"));
        if (user.getStatus() == UserStatus.PENDING) throw new UnauthorizedException("Account pending admin approval");
        if (user.getStatus() == UserStatus.INACTIVE) throw new UnauthorizedException("Account has been deactivated");
        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) throw new UnauthorizedException("Invalid email or password");
        String token = jwtUtil.generateToken(user.getEmail(), user.getRole().name());
        log.info("Login successful: {}", user.getEmail());
        return AuthResponse.builder().id(user.getId()).token(token).name(user.getName()).email(user.getEmail()).role(user.getRole()).status(user.getStatus()).message("Login successful").build();
    }
}

package com.agrosupply.auth.security;
import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import java.nio.charset.StandardCharsets;
import java.security.Key;
import java.util.Date;
@Component
public class JwtUtil {
    @Value("${application.jwt.secret}") private String secretKey;
    @Value("${application.jwt.expiration}") private long expirationMs;
    public String generateToken(String email, String role) {
        return Jwts.builder().setSubject(email).claim("role", role).setIssuedAt(new Date())
            .setExpiration(new Date(System.currentTimeMillis() + expirationMs))
            .signWith(getSigningKey(), SignatureAlgorithm.HS256).compact();
    }
    public String extractEmail(String token) { return parseClaims(token).getSubject(); }
    public boolean isTokenValid(String token) {
        try { parseClaims(token); return true; } catch (Exception e) { return false; }
    }
    private Claims parseClaims(String token) {
        return Jwts.parserBuilder().setSigningKey(getSigningKey()).build().parseClaimsJws(token).getBody();
    }
    private Key getSigningKey() {
        byte[] keyBytes = secretKey.getBytes(StandardCharsets.UTF_8);
        if (keyBytes.length < 32) { byte[] padded = new byte[32]; System.arraycopy(keyBytes, 0, padded, 0, keyBytes.length); return Keys.hmacShaKeyFor(padded); }
        return Keys.hmacShaKeyFor(keyBytes);
    }
}

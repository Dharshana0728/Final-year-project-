package com.agrosupply.auth.dto.response;
import com.agrosupply.auth.enums.Role;
import com.agrosupply.auth.enums.UserStatus;
import lombok.*;
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class AuthResponse {
    private Long id;
    private String token;
    private String name;
    private String email;
    private Role role;
    private UserStatus status;
    private String message;
}

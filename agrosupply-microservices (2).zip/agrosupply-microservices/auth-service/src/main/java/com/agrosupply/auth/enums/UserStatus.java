package com.agrosupply.auth.enums;
public enum UserStatus { PENDING, ACTIVE, INACTIVE }

package com.agrosupply.auth.enums;
public enum Role { ADMIN, PROCUREMENT, WAREHOUSE, DELIVERY, FARMER }

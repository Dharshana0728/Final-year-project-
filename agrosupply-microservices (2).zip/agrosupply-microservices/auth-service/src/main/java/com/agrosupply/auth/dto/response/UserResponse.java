package com.agrosupply.auth.dto.response;
import com.agrosupply.auth.enums.Role;
import com.agrosupply.auth.enums.UserStatus;
import lombok.*;
import java.time.LocalDateTime;
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class UserResponse {
    private Long id;
    private String name;
    private String email;
    private String phone;
    private String location;
    private Role role;
    private UserStatus status;
    private LocalDateTime createdAt;
}

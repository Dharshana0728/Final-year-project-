package com.agrosupply.auth.service;
import com.agrosupply.auth.dto.response.UserResponse;
import com.agrosupply.auth.entity.User;
import com.agrosupply.auth.enums.*;
import com.agrosupply.auth.exception.ResourceNotFoundException;
import com.agrosupply.auth.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;
@Slf4j @Service @RequiredArgsConstructor
public class UserService {
    private final UserRepository userRepository;
    public List<UserResponse> getAllUsers() { return userRepository.findAll().stream().map(this::toResponse).collect(Collectors.toList()); }
    public UserResponse getUserById(Long id) { return toResponse(userRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + id))); }
    public List<UserResponse> getActiveDeliveryAgents() { return userRepository.findByRoleAndStatus(Role.DELIVERY, UserStatus.ACTIVE).stream().map(this::toResponse).collect(Collectors.toList()); }
    public UserResponse updateUserStatus(Long id, UserStatus status) {
        User user = userRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("User not found with id: " + id));
        user.setStatus(status); userRepository.save(user);
        return toResponse(user);
    }
    public UserResponse toResponse(User user) {
        return UserResponse.builder().id(user.getId()).name(user.getName()).email(user.getEmail())
            .phone(user.getPhone()).location(user.getLocation()).role(user.getRole()).status(user.getStatus()).createdAt(user.getCreatedAt()).build();
    }
}

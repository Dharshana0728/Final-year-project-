package com.agrosupply.warehouse.dto.request;
import jakarta.validation.constraints.*;
import lombok.Data;
@Data public class StockTransferRequest { @NotNull private Long fromWarehouseId; @NotNull private Long toWarehouseId; @NotNull private Long productId; @NotNull @Positive private Double quantity; }

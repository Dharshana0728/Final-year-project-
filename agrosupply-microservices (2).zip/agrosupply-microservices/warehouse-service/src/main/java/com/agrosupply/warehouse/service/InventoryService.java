package com.agrosupply.warehouse.service;
import com.agrosupply.warehouse.dto.request.*;
import com.agrosupply.warehouse.dto.response.*;
import com.agrosupply.warehouse.entity.*;
import com.agrosupply.warehouse.enums.WarehouseStatus;
import com.agrosupply.warehouse.exception.*;
import com.agrosupply.warehouse.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j @Service @RequiredArgsConstructor
public class InventoryService {
    private final InventoryRepository inventoryRepository;
    private final WarehouseRepository warehouseRepository;
    private final CapacityValidator capacityValidator;

    public List<InventoryResponse> getAllInventory() {
        return inventoryRepository.findAll().stream().map(this::toResponse).collect(Collectors.toList());
    }

    public List<InventoryResponse> getByWarehouse(Long wid) {
        return inventoryRepository.findByWarehouseId(wid).stream().map(this::toResponse).collect(Collectors.toList());
    }

    @Transactional
    public void receiveStock(ReceiveStockRequest request) {
        Warehouse wh = warehouseRepository.findById(request.getWarehouseId())
            .orElseThrow(() -> new ResourceNotFoundException("Warehouse not found: " + request.getWarehouseId()));

        for (ReceiveStockRequest.StockItem item : request.getItems()) {
            capacityValidator.validate(wh, item.getProductUnit(), item.getQuantity());

            inventoryRepository.findByWarehouseIdAndProductId(wh.getId(), item.getProductId())
                .ifPresentOrElse(inv -> {
                    inv.setQuantityAvailable(inv.getQuantityAvailable() + item.getQuantity());
                    inv.setLastUpdatedAt(LocalDateTime.now());
                    inventoryRepository.save(inv);
                }, () -> {
                    Inventory newInv = new Inventory();
                    newInv.setWarehouse(wh);
                    newInv.setProductId(item.getProductId());
                    newInv.setProductName(item.getProductName());
                    newInv.setProductUnit(item.getProductUnit());
                    newInv.setQuantityAvailable(item.getQuantity());
                    newInv.setLastUpdatedAt(LocalDateTime.now());
                    inventoryRepository.save(newInv);
                });
        }
    }

    @Transactional
    public CheckAndDeductResponse checkAndDeduct(CheckAndDeductRequest request) {
        List<Warehouse> activeWarehouses = warehouseRepository.findByStatus(WarehouseStatus.ACTIVE);
        for (Warehouse wh : activeWarehouses) {
            boolean canFulfill = request.getItems().stream().allMatch(item -> {
                Inventory inv = inventoryRepository.findByWarehouseIdAndProductId(wh.getId(), item.getProductId()).orElse(null);
                return inv != null && inv.getQuantityAvailable() >= item.getQuantity();
            });
            if (canFulfill) {
                for (var item : request.getItems()) {
                    Inventory inv = inventoryRepository.findByWarehouseIdAndProductId(wh.getId(), item.getProductId()).get();
                    inv.setQuantityAvailable(inv.getQuantityAvailable() - item.getQuantity());
                    inv.setLastUpdatedAt(LocalDateTime.now());
                    inventoryRepository.save(inv);
                }
                return CheckAndDeductResponse.builder().warehouseId(wh.getId()).warehouseName(wh.getName()).build();
            }
        }
        throw new InsufficientStockException("No warehouse has sufficient stock for all requested items");
    }

    @Transactional
    public void restoreStock(Long warehouseId, RestoreStockRequest request) {
        Warehouse wh = warehouseRepository.findById(warehouseId)
            .orElseThrow(() -> new ResourceNotFoundException("Warehouse not found: " + warehouseId));
        for (var item : request.getItems()) {
            inventoryRepository.findByWarehouseIdAndProductId(wh.getId(), item.getProductId())
                .ifPresent(inv -> {
                    inv.setQuantityAvailable(inv.getQuantityAvailable() + item.getQuantity());
                    inv.setLastUpdatedAt(LocalDateTime.now());
                    inventoryRepository.save(inv);
                });
        }
    }

    private InventoryResponse toResponse(Inventory i) {
        return InventoryResponse.builder()
            .id(i.getId())
            .warehouseId(i.getWarehouse().getId())
            .warehouseName(i.getWarehouse().getName())
            .productId(i.getProductId())
            .productName(i.getProductName())
            .productUnit(i.getProductUnit())
            .quantityAvailable(i.getQuantityAvailable())
            .lastUpdatedAt(i.getLastUpdatedAt())
            .build();
    }
}
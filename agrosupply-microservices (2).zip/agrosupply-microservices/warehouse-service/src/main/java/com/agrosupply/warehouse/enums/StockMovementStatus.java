package com.agrosupply.warehouse.enums;
public enum StockMovementStatus { PENDING, APPROVED, REJECTED }

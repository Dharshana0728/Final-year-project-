package com.agrosupply.warehouse.service;
import com.agrosupply.warehouse.dto.request.WarehouseRequest;
import com.agrosupply.warehouse.dto.response.WarehouseResponse;
import com.agrosupply.warehouse.entity.Warehouse;
import com.agrosupply.warehouse.enums.WarehouseStatus;
import com.agrosupply.warehouse.exception.*;
import com.agrosupply.warehouse.repository.WarehouseRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.stream.Collectors;
@Slf4j @Service @RequiredArgsConstructor
public class WarehouseService {
    private final WarehouseRepository warehouseRepository;
    public WarehouseResponse createWarehouse(WarehouseRequest r) {
        Warehouse w = warehouseRepository.save(Warehouse.builder().name(r.getName()).location(r.getLocation()).maxCapacityKg(r.getMaxCapacityKg()).maxCapacityLitre(r.getMaxCapacityLitre()).maxCapacityPiece(r.getMaxCapacityPiece()).status(WarehouseStatus.ACTIVE).build());
        return toResponse(w);
    }
    public List<WarehouseResponse> getAllWarehouses() { return warehouseRepository.findAll().stream().map(this::toResponse).collect(Collectors.toList()); }
    public WarehouseResponse assignOperator(Long wid, Long opId, String opName) {
        Warehouse w = warehouseRepository.findById(wid).orElseThrow(() -> new ResourceNotFoundException("Warehouse not found: " + wid));
        w.setOperatorId(opId); w.setOperatorName(opName); return toResponse(warehouseRepository.save(w));
    }
    public WarehouseResponse updateStatus(Long id, WarehouseStatus status) {
        Warehouse w = warehouseRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Warehouse not found: " + id));
        w.setStatus(status); return toResponse(warehouseRepository.save(w));
    }
    public WarehouseResponse toResponse(Warehouse w) {
        return WarehouseResponse.builder().id(w.getId()).name(w.getName()).location(w.getLocation()).maxCapacityKg(w.getMaxCapacityKg()).maxCapacityLitre(w.getMaxCapacityLitre()).maxCapacityPiece(w.getMaxCapacityPiece()).operatorId(w.getOperatorId()).operatorName(w.getOperatorName()).status(w.getStatus()).build();
    }
}

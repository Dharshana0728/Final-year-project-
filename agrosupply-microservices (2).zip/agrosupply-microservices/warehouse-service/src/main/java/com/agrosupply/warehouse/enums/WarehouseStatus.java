package com.agrosupply.warehouse.enums;
public enum WarehouseStatus { ACTIVE, INACTIVE }

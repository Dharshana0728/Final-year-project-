package com.agrosupply.warehouse.dto.response;
import com.agrosupply.warehouse.enums.WarehouseStatus;
import lombok.*;
@Data @Builder public class WarehouseResponse { private Long id; private String name; private String location; private Double maxCapacityKg; private Double maxCapacityLitre; private Double maxCapacityPiece; private Long operatorId; private String operatorName; private WarehouseStatus status; }

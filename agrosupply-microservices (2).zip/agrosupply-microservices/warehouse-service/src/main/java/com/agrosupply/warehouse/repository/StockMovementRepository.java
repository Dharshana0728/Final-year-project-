package com.agrosupply.warehouse.repository;
import com.agrosupply.warehouse.entity.StockMovement;
import com.agrosupply.warehouse.enums.StockMovementStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface StockMovementRepository extends JpaRepository<StockMovement, Long> {
    List<StockMovement> findByStatus(StockMovementStatus status);
    List<StockMovement> findByFromWarehouseId(Long id);
    List<StockMovement> findByToWarehouseId(Long id);
}

package com.agrosupply.warehouse.repository;
import com.agrosupply.warehouse.entity.Inventory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.*;

public interface InventoryRepository extends JpaRepository<Inventory, Long> {
    List<Inventory> findByWarehouseId(Long warehouseId);
    Optional<Inventory> findByWarehouseIdAndProductId(Long warehouseId, Long productId);

    @Query("SELECT COALESCE(SUM(i.quantityAvailable), 0.0) FROM Inventory i WHERE i.warehouse.id = :wid AND LOWER(i.productUnit) = 'kg'")
    Double getTotalKg(@Param("wid") Long wid);

    @Query("SELECT COALESCE(SUM(i.quantityAvailable), 0.0) FROM Inventory i WHERE i.warehouse.id = :wid AND LOWER(i.productUnit) = 'litre'")
    Double getTotalLitre(@Param("wid") Long wid);

    @Query("SELECT COALESCE(SUM(i.quantityAvailable), 0.0) FROM Inventory i WHERE i.warehouse.id = :wid AND LOWER(i.productUnit) = 'piece'")
    Double getTotalPiece(@Param("wid") Long wid);
}
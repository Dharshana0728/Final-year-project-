package com.agrosupply.warehouse.dto.request;
import lombok.Data;
import java.util.List;
@Data public class ReceiveStockRequest { private Long warehouseId; private List<StockItem> items; @Data public static class StockItem { private Long productId; private String productName; private String productUnit; private Double quantity; } }

package com.agrosupply.warehouse.dto.request;
import lombok.Data;
import java.util.List;
@Data public class RestoreStockRequest { private List<Item> items; @Data public static class Item { private Long productId; private Double quantity; } }

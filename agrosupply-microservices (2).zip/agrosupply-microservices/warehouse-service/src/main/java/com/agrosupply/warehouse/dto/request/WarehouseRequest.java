package com.agrosupply.warehouse.dto.request;
import jakarta.validation.constraints.*;
import lombok.Data;
@Data public class WarehouseRequest { @NotBlank private String name; @NotBlank private String location; @NotNull @Positive private Double maxCapacityKg; @NotNull @Positive private Double maxCapacityLitre; @NotNull @Positive private Double maxCapacityPiece; }

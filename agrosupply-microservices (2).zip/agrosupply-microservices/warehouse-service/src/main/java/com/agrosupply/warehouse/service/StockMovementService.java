package com.agrosupply.warehouse.service;
import com.agrosupply.warehouse.dto.request.StockTransferRequest;
import com.agrosupply.warehouse.dto.response.StockMovementResponse;
import com.agrosupply.warehouse.entity.*;
import com.agrosupply.warehouse.enums.StockMovementStatus;
import com.agrosupply.warehouse.exception.*;
import com.agrosupply.warehouse.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;
@Slf4j @Service @RequiredArgsConstructor
public class StockMovementService {
    private final StockMovementRepository stockMovementRepository;
    private final WarehouseRepository warehouseRepository;
    private final InventoryRepository inventoryRepository;
    private final CapacityValidator capacityValidator;

    @Transactional
    public StockMovementResponse requestTransfer(StockTransferRequest request) {
        Warehouse from = warehouseRepository.findById(request.getFromWarehouseId()).orElseThrow(() -> new ResourceNotFoundException("Source warehouse not found"));
        Warehouse to = warehouseRepository.findById(request.getToWarehouseId()).orElseThrow(() -> new ResourceNotFoundException("Destination warehouse not found"));
        if (from.getId().equals(to.getId())) throw new BadRequestException("Source and destination cannot be the same");
        Inventory srcInv = inventoryRepository.findByWarehouseIdAndProductId(from.getId(), request.getProductId()).orElseThrow(() -> new InsufficientStockException("Product not found in source warehouse"));
        if (srcInv.getQuantityAvailable() < request.getQuantity()) throw new InsufficientStockException("Insufficient stock. Available: " + srcInv.getQuantityAvailable());
        capacityValidator.validate(to, srcInv.getProductUnit(), request.getQuantity());
        StockMovement m = stockMovementRepository.save(StockMovement.builder().fromWarehouse(from).toWarehouse(to).productId(request.getProductId()).productName(srcInv.getProductName()).productUnit(srcInv.getProductUnit()).quantity(request.getQuantity()).status(StockMovementStatus.PENDING).build());
        return toResponse(m);
    }

    @Transactional
    public StockMovementResponse approveTransfer(Long id) {
        StockMovement m = stockMovementRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Movement not found: " + id));
        if (m.getStatus() != StockMovementStatus.PENDING) throw new BadRequestException("Only PENDING transfers can be approved");
        Inventory srcInv = inventoryRepository.findByWarehouseIdAndProductId(m.getFromWarehouse().getId(), m.getProductId()).orElseThrow(() -> new ResourceNotFoundException("Source inventory not found"));
        if (srcInv.getQuantityAvailable() < m.getQuantity()) throw new InsufficientStockException("Insufficient stock at approval time");
        capacityValidator.validate(m.getToWarehouse(), m.getProductUnit(), m.getQuantity());
        srcInv.setQuantityAvailable(srcInv.getQuantityAvailable() - m.getQuantity()); srcInv.setLastUpdatedAt(LocalDateTime.now()); inventoryRepository.save(srcInv);
        Inventory dstInv = inventoryRepository.findByWarehouseIdAndProductId(m.getToWarehouse().getId(), m.getProductId()).orElse(null);
        if (dstInv != null) { dstInv.setQuantityAvailable(dstInv.getQuantityAvailable() + m.getQuantity()); dstInv.setLastUpdatedAt(LocalDateTime.now()); inventoryRepository.save(dstInv); }
        else inventoryRepository.save(Inventory.builder().warehouse(m.getToWarehouse()).productId(m.getProductId()).productName(m.getProductName()).productUnit(m.getProductUnit()).quantityAvailable(m.getQuantity()).lastUpdatedAt(LocalDateTime.now()).build());
        m.setStatus(StockMovementStatus.APPROVED); m.setResolvedAt(LocalDateTime.now());
        return toResponse(stockMovementRepository.save(m));
    }

    @Transactional
    public StockMovementResponse rejectTransfer(Long id) {
        StockMovement m = stockMovementRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("Movement not found: " + id));
        if (m.getStatus() != StockMovementStatus.PENDING) throw new BadRequestException("Only PENDING transfers can be rejected");
        m.setStatus(StockMovementStatus.REJECTED); m.setResolvedAt(LocalDateTime.now());
        return toResponse(stockMovementRepository.save(m));
    }

    public List<StockMovementResponse> getAllMovements() { return stockMovementRepository.findAll().stream().map(this::toResponse).collect(Collectors.toList()); }

    private StockMovementResponse toResponse(StockMovement m) {
        return StockMovementResponse.builder().id(m.getId()).fromWarehouseId(m.getFromWarehouse().getId()).fromWarehouseName(m.getFromWarehouse().getName()).toWarehouseId(m.getToWarehouse().getId()).toWarehouseName(m.getToWarehouse().getName()).productId(m.getProductId()).productName(m.getProductName()).quantity(m.getQuantity()).status(m.getStatus()).requestedAt(m.getRequestedAt()).resolvedAt(m.getResolvedAt()).build();
    }
}

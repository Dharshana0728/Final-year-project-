package com.agrosupply.warehouse.dto.response;
import lombok.*;
@Data @Builder @NoArgsConstructor @AllArgsConstructor
public class CheckAndDeductResponse { private Long warehouseId; private String warehouseName; }

package com.agrosupply.warehouse.dto.request;
import lombok.Data;
import java.util.List;
@Data public class CheckAndDeductRequest { private List<Item> items; @Data public static class Item { private Long productId; private String productUnit; private Double quantity; } }

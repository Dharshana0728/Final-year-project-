package com.agrosupply.warehouse.controller;
import com.agrosupply.warehouse.dto.request.WarehouseRequest;
import com.agrosupply.warehouse.dto.response.WarehouseResponse;
import com.agrosupply.warehouse.enums.WarehouseStatus;
import com.agrosupply.warehouse.service.WarehouseService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController @RequestMapping("/api/warehouses") @RequiredArgsConstructor
public class WarehouseController {
    private final WarehouseService warehouseService;
    @PostMapping public ResponseEntity<WarehouseResponse> create(@Valid @RequestBody WarehouseRequest r) { return ResponseEntity.ok(warehouseService.createWarehouse(r)); }
    @GetMapping public ResponseEntity<List<WarehouseResponse>> getAll() { return ResponseEntity.ok(warehouseService.getAllWarehouses()); }
    @PatchMapping("/{id}/assign-operator") public ResponseEntity<WarehouseResponse> assignOperator(@PathVariable Long id, @RequestParam Long operatorId, @RequestParam String operatorName) { return ResponseEntity.ok(warehouseService.assignOperator(id, operatorId, operatorName)); }
    @PatchMapping("/{id}/status") public ResponseEntity<WarehouseResponse> updateStatus(@PathVariable Long id, @RequestParam WarehouseStatus status) { return ResponseEntity.ok(warehouseService.updateStatus(id, status)); }
}

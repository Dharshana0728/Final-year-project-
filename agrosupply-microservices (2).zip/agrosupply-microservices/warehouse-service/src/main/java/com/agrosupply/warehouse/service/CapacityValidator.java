package com.agrosupply.warehouse.service;
import com.agrosupply.warehouse.entity.Warehouse;
import com.agrosupply.warehouse.exception.CapacityExceededException;
import com.agrosupply.warehouse.repository.InventoryRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

@Component @RequiredArgsConstructor
public class CapacityValidator {
    private final InventoryRepository inventoryRepository;

    public void validate(Warehouse warehouse, String unit, Double incoming) {
        if (unit == null || incoming == null) return;
        switch (unit.toLowerCase()) {
            case "kg" -> {
                Double raw = inventoryRepository.getTotalKg(warehouse.getId());
                double current = raw == null ? 0.0 : raw;
                if (warehouse.getMaxCapacityKg() != null && current + incoming > warehouse.getMaxCapacityKg())
                    throw new CapacityExceededException("Kg capacity exceeded! Max: " + warehouse.getMaxCapacityKg() + ", Current: " + current + ", Incoming: " + incoming);
            }
            case "litre" -> {
                Double raw = inventoryRepository.getTotalLitre(warehouse.getId());
                double current = raw == null ? 0.0 : raw;
                if (warehouse.getMaxCapacityLitre() != null && current + incoming > warehouse.getMaxCapacityLitre())
                    throw new CapacityExceededException("Litre capacity exceeded! Max: " + warehouse.getMaxCapacityLitre() + ", Current: " + current + ", Incoming: " + incoming);
            }
            case "piece" -> {
                Double raw = inventoryRepository.getTotalPiece(warehouse.getId());
                double current = raw == null ? 0.0 : raw;
                if (warehouse.getMaxCapacityPiece() != null && current + incoming > warehouse.getMaxCapacityPiece())
                    throw new CapacityExceededException("Piece capacity exceeded! Max: " + warehouse.getMaxCapacityPiece() + ", Current: " + current + ", Incoming: " + incoming);
            }
            default -> { /* unknown unit — skip capacity check */ }
        }
    }
}
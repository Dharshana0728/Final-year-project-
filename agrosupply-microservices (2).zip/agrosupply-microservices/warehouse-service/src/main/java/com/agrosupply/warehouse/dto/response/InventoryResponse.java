package com.agrosupply.warehouse.dto.response;
import lombok.*;
import java.time.LocalDateTime;
@Data @Builder public class InventoryResponse { private Long id; private Long warehouseId; private String warehouseName; private Long productId; private String productName; private String productUnit; private Double quantityAvailable; private LocalDateTime lastUpdatedAt; }

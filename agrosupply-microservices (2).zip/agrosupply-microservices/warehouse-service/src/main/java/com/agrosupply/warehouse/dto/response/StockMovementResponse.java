package com.agrosupply.warehouse.dto.response;
import com.agrosupply.warehouse.enums.StockMovementStatus;
import lombok.*;
import java.time.LocalDateTime;
@Data @Builder public class StockMovementResponse { private Long id; private Long fromWarehouseId; private String fromWarehouseName; private Long toWarehouseId; private String toWarehouseName; private Long productId; private String productName; private Double quantity; private StockMovementStatus status; private LocalDateTime requestedAt; private LocalDateTime resolvedAt; }

package com.agrosupply.warehouse.controller;
import com.agrosupply.warehouse.dto.request.*;
import com.agrosupply.warehouse.dto.response.*;
import com.agrosupply.warehouse.service.InventoryService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController @RequestMapping("/api/inventory") @RequiredArgsConstructor
public class InventoryController {
    private final InventoryService inventoryService;
    @GetMapping public ResponseEntity<List<InventoryResponse>> getAll() { return ResponseEntity.ok(inventoryService.getAllInventory()); }
    @GetMapping("/warehouse/{id}") public ResponseEntity<List<InventoryResponse>> getByWarehouse(@PathVariable Long id) { return ResponseEntity.ok(inventoryService.getByWarehouse(id)); }
    @PostMapping("/receive") public ResponseEntity<Void> receiveStock(@RequestBody ReceiveStockRequest r) { inventoryService.receiveStock(r); return ResponseEntity.ok().build(); }
    @PostMapping("/check-and-deduct") public ResponseEntity<CheckAndDeductResponse> checkAndDeduct(@RequestBody CheckAndDeductRequest r) { return ResponseEntity.ok(inventoryService.checkAndDeduct(r)); }
    @PostMapping("/restore/{warehouseId}") public ResponseEntity<Void> restoreStock(@PathVariable Long warehouseId, @RequestBody RestoreStockRequest r) { inventoryService.restoreStock(warehouseId, r); return ResponseEntity.ok().build(); }
}

package com.agrosupply.warehouse.entity;
import com.agrosupply.warehouse.enums.WarehouseStatus;
import jakarta.persistence.*;
import lombok.*;
@Entity @Table(name = "warehouses") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Warehouse {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(nullable = false) private String name;
    @Column(nullable = false) private String location;
    private Double maxCapacityKg;
    private Double maxCapacityLitre;
    private Double maxCapacityPiece;
    private Long operatorId;
    private String operatorName;
    @Enumerated(EnumType.STRING) @Column(nullable = false) private WarehouseStatus status;
}

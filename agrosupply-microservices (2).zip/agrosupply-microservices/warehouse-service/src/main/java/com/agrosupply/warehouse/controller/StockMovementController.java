package com.agrosupply.warehouse.controller;
import com.agrosupply.warehouse.dto.request.StockTransferRequest;
import com.agrosupply.warehouse.dto.response.StockMovementResponse;
import com.agrosupply.warehouse.service.StockMovementService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController @RequestMapping("/api/stock-movements") @RequiredArgsConstructor
public class StockMovementController {
    private final StockMovementService stockMovementService;
    @PostMapping("/transfer") public ResponseEntity<StockMovementResponse> transfer(@Valid @RequestBody StockTransferRequest r) { return ResponseEntity.ok(stockMovementService.requestTransfer(r)); }
    @GetMapping public ResponseEntity<List<StockMovementResponse>> getAll() { return ResponseEntity.ok(stockMovementService.getAllMovements()); }
    @PatchMapping("/{id}/approve") public ResponseEntity<StockMovementResponse> approve(@PathVariable Long id) { return ResponseEntity.ok(stockMovementService.approveTransfer(id)); }
    @PatchMapping("/{id}/reject") public ResponseEntity<StockMovementResponse> reject(@PathVariable Long id) { return ResponseEntity.ok(stockMovementService.rejectTransfer(id)); }
}

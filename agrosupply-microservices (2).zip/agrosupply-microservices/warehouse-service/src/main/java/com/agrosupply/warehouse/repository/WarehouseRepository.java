package com.agrosupply.warehouse.repository;
import com.agrosupply.warehouse.entity.Warehouse;
import com.agrosupply.warehouse.enums.WarehouseStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface WarehouseRepository extends JpaRepository<Warehouse, Long> {
    List<Warehouse> findByStatus(WarehouseStatus status);
}

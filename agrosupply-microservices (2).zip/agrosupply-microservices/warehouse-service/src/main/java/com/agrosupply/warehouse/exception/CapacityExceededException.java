package com.agrosupply.warehouse.exception;
public class CapacityExceededException extends RuntimeException { public CapacityExceededException(String m) { super(m); } }

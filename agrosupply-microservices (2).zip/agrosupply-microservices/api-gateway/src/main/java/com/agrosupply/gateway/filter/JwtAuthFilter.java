package com.agrosupply.gateway.filter;

import io.jsonwebtoken.Claims;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.Ordered;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Map;
import java.util.Set;

@Component
public class JwtAuthFilter implements GlobalFilter, Ordered {

    @Autowired private JwtUtil jwtUtil;

    // Paths that require no token at all
    private static final List<String> PUBLIC_PATHS = List.of(
        "/api/auth/register", "/api/auth/login",
        "/swagger-ui", "/v3/api-docs",
        "/auth/v3/api-docs", "/product/v3/api-docs",
        "/warehouse/v3/api-docs", "/request/v3/api-docs",
        "/delivery/v3/api-docs", "/invoice/v3/api-docs"
    );

    // Internal service-to-service paths — validated by JWT already, skip role check
    private static final List<String> INTERNAL_PATHS = List.of(
        "/api/requests/internal/",
        "/api/deliveries/internal/",
        "/api/invoices/internal/"
    );

    // Role-based access rules: path prefix → allowed roles
    // If a path is not listed here, any authenticated user can access it
    private static final Map<String, Set<String>> ROLE_RULES = Map.ofEntries(
        // Admin only
        Map.entry("/api/users",           Set.of("ADMIN","WAREHOUSE")),
        // Admin + Procurement
        Map.entry("/api/suppliers",       Set.of("ADMIN", "PROCUREMENT")),
        Map.entry("/api/supplier-orders", Set.of("ADMIN", "PROCUREMENT")),
        // Admin + Warehouse
        Map.entry("/api/warehouses",      Set.of("ADMIN", "WAREHOUSE","PROCUREMENT")),
        Map.entry("/api/inventory",       Set.of("ADMIN", "WAREHOUSE")),
        Map.entry("/api/stock-movements", Set.of("ADMIN", "WAREHOUSE")),
        // Admin + Delivery
        Map.entry("/api/deliveries",      Set.of("ADMIN", "DELIVERY")),
        // Admin + Farmer
        Map.entry("/api/requests",        Set.of("ADMIN", "FARMER", "WAREHOUSE")),
        Map.entry("/api/invoices",        Set.of("ADMIN", "PROCUREMENT", "FARMER"))
    );

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
        String path   = exchange.getRequest().getURI().getPath();
        String method = exchange.getRequest().getMethod().name();

        // Let OPTIONS preflight through — CorsWebFilter handles it
        if ("OPTIONS".equalsIgnoreCase(method)) {
            return chain.filter(exchange);
        }

        // Public paths — no token needed
        for (String pub : PUBLIC_PATHS) {
            if (path.startsWith(pub)) return chain.filter(exchange);
        }

        // Internal inter-service paths — require valid token but skip role check
        for (String internal : INTERNAL_PATHS) {
            if (path.startsWith(internal)) {
                return validateTokenOnly(exchange, chain);
            }
        }

        // All other paths — validate token AND check role
        return validateTokenAndRole(exchange, chain, path);
    }

    private Mono<Void> validateTokenOnly(ServerWebExchange exchange, GatewayFilterChain chain) {
        String authHeader = exchange.getRequest().getHeaders().getFirst("Authorization");
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            return errorResponse(exchange, HttpStatus.UNAUTHORIZED, "Missing token");
        }
        String token = authHeader.substring(7);
        if (!jwtUtil.isTokenValid(token)) {
            return errorResponse(exchange, HttpStatus.UNAUTHORIZED, "Invalid token");
        }
        return chain.filter(exchange);
    }

    private Mono<Void> validateTokenAndRole(ServerWebExchange exchange, GatewayFilterChain chain, String path) {
        String authHeader = exchange.getRequest().getHeaders().getFirst("Authorization");
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            return errorResponse(exchange, HttpStatus.UNAUTHORIZED, "Missing or invalid Authorization header");
        }

        String token = authHeader.substring(7);
        if (!jwtUtil.isTokenValid(token)) {
            return errorResponse(exchange, HttpStatus.UNAUTHORIZED, "Invalid or expired JWT token");
        }

        Claims claims = jwtUtil.extractAllClaims(token);
        String email = claims.getSubject();
        String role  = (String) claims.get("role");

        // Check role-based access rules
        for (Map.Entry<String, Set<String>> rule : ROLE_RULES.entrySet()) {
            if (path.startsWith(rule.getKey())) {
                if (role == null || !rule.getValue().contains(role)) {
                    return errorResponse(exchange, HttpStatus.FORBIDDEN,
                        "Access denied: role " + role + " cannot access " + path);
                }
                break;
            }
        }

        // Forward user info as headers to downstream services
        ServerHttpRequest mutatedRequest = exchange.getRequest().mutate()
            .header("X-User-Email", email != null ? email : "")
            .header("X-User-Role",  role  != null ? role  : "")
            .build();

        return chain.filter(exchange.mutate().request(mutatedRequest).build());
    }

    private Mono<Void> errorResponse(ServerWebExchange exchange, HttpStatus status, String message) {
        ServerHttpResponse response = exchange.getResponse();
        response.setStatusCode(status);
        response.getHeaders().setContentType(MediaType.APPLICATION_JSON);
        String body = "{\"status\":" + status.value() + ",\"error\":\"" + status.getReasonPhrase() + "\",\"message\":\"" + message + "\"}";
        return response.writeWith(Mono.just(response.bufferFactory().wrap(body.getBytes())));
    }

    @Override
    public int getOrder() { return -1; }
}

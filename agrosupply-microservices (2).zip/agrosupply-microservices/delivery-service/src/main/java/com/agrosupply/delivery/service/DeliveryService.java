package com.agrosupply.delivery.service;

import com.agrosupply.delivery.client.*;
import com.agrosupply.delivery.dto.response.DeliveryResponse;
import com.agrosupply.delivery.entity.Delivery;
import com.agrosupply.delivery.enums.DeliveryStatus;
import com.agrosupply.delivery.exception.*;
import com.agrosupply.delivery.repository.DeliveryRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j @Service @RequiredArgsConstructor
public class DeliveryService {
    private final DeliveryRepository deliveryRepository;
    private final RequestClient requestClient;
    private final InvoiceClient invoiceClient;

    public Delivery createDelivery(Map<String,Object> payload) {
        Delivery d = deliveryRepository.save(Delivery.builder()
            .requestId(((Number)payload.get("requestId")).longValue())
            .farmerId(((Number)payload.get("farmerId")).longValue())
            .farmerName((String)payload.get("farmerName"))
            .warehouseId(((Number)payload.get("warehouseId")).longValue())
            .warehouseName((String)payload.get("warehouseName"))
            .deliveryAgentId(((Number)payload.get("deliveryAgentId")).longValue())
            .deliveryAgentName((String)payload.get("deliveryAgentName"))
            .status(DeliveryStatus.IN_PROGRESS).build());
        log.info("Delivery #{} created for requestId: {}", d.getId(), d.getRequestId());
        return d;
    }

    public List<DeliveryResponse> getAllDeliveries() { return deliveryRepository.findAll().stream().map(this::toResponse).collect(Collectors.toList()); }
    public List<DeliveryResponse> getDeliveriesByAgent(Long agentId) { return deliveryRepository.findByDeliveryAgentId(agentId).stream().map(this::toResponse).collect(Collectors.toList()); }

    @Transactional
    public DeliveryResponse completeDelivery(Long deliveryId) {
        log.info("Completing delivery: {}", deliveryId);
        Delivery d = deliveryRepository.findById(deliveryId).orElseThrow(() -> new ResourceNotFoundException("Delivery not found: " + deliveryId));
        if (d.getStatus() == DeliveryStatus.COMPLETED) throw new BadRequestException("Delivery already completed");

        // Trigger 1: Mark delivery completed
        d.setStatus(DeliveryStatus.COMPLETED); d.setDeliveredAt(LocalDateTime.now()); deliveryRepository.save(d);

        // Trigger 2: Mark request delivered
        requestClient.markDelivered(d.getRequestId());

        // Trigger 3: Get request items, calculate total, create invoice
        Map<String,Object> requestData = requestClient.getRequest(d.getRequestId());
        List<Map<String,Object>> items = (List<Map<String,Object>>) requestData.get("items");
        BigDecimal total = items.stream().map(item -> {
            BigDecimal price = new BigDecimal(item.get("productPrice").toString());
            Double qty = ((Number)item.get("quantity")).doubleValue();
            return price.multiply(BigDecimal.valueOf(qty));
        }).reduce(BigDecimal.ZERO, BigDecimal::add);

        Map<String,Object> invoicePayload = new HashMap<>();
        invoicePayload.put("requestId", d.getRequestId());
        invoicePayload.put("farmerId", d.getFarmerId());
        invoicePayload.put("farmerName", d.getFarmerName());
        invoicePayload.put("totalAmount", total);
        invoiceClient.createInvoice(invoicePayload);

        log.info("Delivery #{} completed — invoice created, total: {}", deliveryId, total);
        return toResponse(d);
    }

    private DeliveryResponse toResponse(Delivery d) {
        return DeliveryResponse.builder().id(d.getId()).requestId(d.getRequestId()).farmerId(d.getFarmerId()).farmerName(d.getFarmerName()).warehouseId(d.getWarehouseId()).warehouseName(d.getWarehouseName()).deliveryAgentId(d.getDeliveryAgentId()).deliveryAgentName(d.getDeliveryAgentName()).status(d.getStatus()).deliveredAt(d.getDeliveredAt()).build();
    }
}

package com.agrosupply.delivery.client;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import com.agrosupply.delivery.config.FeignConfig;

import java.util.Map;
@FeignClient(name = "INVOICE-SERVICE", configuration = FeignConfig.class)
public interface InvoiceClient {
    @PostMapping("/api/invoices/internal/create") Map<String,Object> createInvoice(@RequestBody Map<String,Object> payload);
}

package com.agrosupply.delivery.controller;
import com.agrosupply.delivery.dto.response.DeliveryResponse;
import com.agrosupply.delivery.entity.Delivery;
import com.agrosupply.delivery.service.DeliveryService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;
@RestController @RequestMapping("/api/deliveries") @RequiredArgsConstructor
public class DeliveryController {
    private final DeliveryService deliveryService;
    @GetMapping public ResponseEntity<List<DeliveryResponse>> getAll() { return ResponseEntity.ok(deliveryService.getAllDeliveries()); }
    @GetMapping("/agent/{agentId}") public ResponseEntity<List<DeliveryResponse>> getByAgent(@PathVariable Long agentId) { return ResponseEntity.ok(deliveryService.getDeliveriesByAgent(agentId)); }
    @PatchMapping("/{id}/complete") public ResponseEntity<DeliveryResponse> complete(@PathVariable Long id) { return ResponseEntity.ok(deliveryService.completeDelivery(id)); }
    @PostMapping("/internal/create") public ResponseEntity<Delivery> createInternal(@RequestBody Map<String,Object> payload) { return ResponseEntity.ok(deliveryService.createDelivery(payload)); }
}

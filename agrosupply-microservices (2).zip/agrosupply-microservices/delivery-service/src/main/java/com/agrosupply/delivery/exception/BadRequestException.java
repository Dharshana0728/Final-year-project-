package com.agrosupply.delivery.exception;
public class BadRequestException extends RuntimeException { public BadRequestException(String m) { super(m); } }

package com.agrosupply.delivery.repository;
import com.agrosupply.delivery.entity.Delivery;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.*;
public interface DeliveryRepository extends JpaRepository<Delivery, Long> {
    List<Delivery> findByDeliveryAgentId(Long id);
    Optional<Delivery> findByRequestId(Long requestId);
}

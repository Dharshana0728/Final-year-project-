package com.agrosupply.delivery.entity;
import com.agrosupply.delivery.enums.DeliveryStatus;
import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;
@Entity @Table(name = "deliveries") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Delivery {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(name = "request_id", nullable = false) private Long requestId;
    @Column(name = "farmer_id") private Long farmerId;
    @Column(name = "farmer_name") private String farmerName;
    @Column(name = "warehouse_id") private Long warehouseId;
    @Column(name = "warehouse_name") private String warehouseName;
    @Column(name = "delivery_agent_id") private Long deliveryAgentId;
    @Column(name = "delivery_agent_name") private String deliveryAgentName;
    @Enumerated(EnumType.STRING) @Column(nullable = false) private DeliveryStatus status;
    private LocalDateTime deliveredAt;
}

package com.agrosupply.delivery.exception;
import org.springframework.http.*; import org.springframework.web.bind.annotation.*; import java.time.LocalDateTime; import java.util.*;
@RestControllerAdvice
public class GlobalExceptionHandler {
    @ExceptionHandler(ResourceNotFoundException.class) public ResponseEntity<Map<String,Object>> h1(ResourceNotFoundException e) { return b(HttpStatus.NOT_FOUND, e.getMessage()); }
    @ExceptionHandler(BadRequestException.class) public ResponseEntity<Map<String,Object>> h2(BadRequestException e) { return b(HttpStatus.BAD_REQUEST, e.getMessage()); }
    private ResponseEntity<Map<String,Object>> b(HttpStatus s, String m) { Map<String,Object> body = new LinkedHashMap<>(); body.put("timestamp", LocalDateTime.now()); body.put("status", s.value()); body.put("error", s.getReasonPhrase()); body.put("message", m); return ResponseEntity.status(s).body(body); }
}

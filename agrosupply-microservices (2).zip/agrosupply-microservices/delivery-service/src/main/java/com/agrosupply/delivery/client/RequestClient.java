package com.agrosupply.delivery.client;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import com.agrosupply.delivery.config.FeignConfig;

import java.util.Map;

@FeignClient(name = "REQUEST-SERVICE", configuration = FeignConfig.class)
public interface RequestClient {
    @PostMapping("/api/requests/internal/{id}/delivered") void markDelivered(@PathVariable Long id);
    @GetMapping("/api/requests/internal/{id}") Map<String,Object> getRequest(@PathVariable Long id);
}
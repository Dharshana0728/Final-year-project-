package com.agrosupply.delivery.enums;
public enum DeliveryStatus { IN_PROGRESS, COMPLETED }

package com.agrosupply.delivery.dto.response;
import com.agrosupply.delivery.enums.DeliveryStatus;
import lombok.*;
import java.time.LocalDateTime;
@Data @Builder public class DeliveryResponse { private Long id; private Long requestId; private Long farmerId; private String farmerName; private Long warehouseId; private String warehouseName; private Long deliveryAgentId; private String deliveryAgentName; private DeliveryStatus status; private LocalDateTime deliveredAt; }
